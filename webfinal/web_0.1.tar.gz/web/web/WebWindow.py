# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# This file is in the public domain
### END LICENSE

import gettext
from gettext import gettext as _
gettext.textdomain('web')

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('web')

from web_lib import Window
from web.AboutWebDialog import AboutWebDialog
from web.PreferencesWebDialog import PreferencesWebDialog

# See web_lib.Window.py for more details about how this class works
class WebWindow(Window):
    __gtype_name__ = "WebWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(WebWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutWebDialog
        self.PreferencesDialog = PreferencesWebDialog

        # Code for other initialization actions should be added here.

        self.refresh = self.builder.get_object("refresh")
        self.url = self.builder.get_object("url")
        self.scrolledwindow = self.builder.get_object("scrolledwindow")        
        self.home = self.builder.get_object("home") 
        self.back = self.builder.get_object("back") 
        self.forward = self.builder.get_object("forward")  
        self.toolbar1 = self.builder.get_object("toolbar1")       
        
        self.webview = WebKit.WebView()
        
        self.scrolledwindow.add(self.webview)
        self.webview.show()

        context = self.toolbar1.get_style_context()
        context.add_class(Gtk.STYLE_CLASS_PRIMARY_TOOLBAR)
        
    def on_url_activate(self, widget):
        url = widget.get_text()

        self.webview.open("http://"+url)

    def on_refresh_clicked(self, widget):
        self.webview.reload()

    def on_home_clicked(self, widget):
        self.webview.open("http://google.com")

    def on_back_clicked(self, widget):
        self.webview.go_back()

    def on_forward_clicked(self, widget):
        self.webview.go_forward()
